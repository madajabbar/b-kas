<?php

namespace App\Http\Traits;
trait ImageTrait{
    public function imageProductStore($data){

    }
}
