<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="table-responsive shop_cart_table">
                        <table class="table">
                            <thead>
                                <tr>
                                    <th>Store</th>
                                    <th>&nbsp;</th>
                                    <th>Product</th>
                                    <th>Price</th>
                                    <th>Quantity</th>
                                    <th>Total</th>
                                    <th>Remove</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data => $productList): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($data); ?></td>
                                        <td colspan="12" class="px-0">
                                            <div class="row g-0 align-items-center">
                                                <div class="col-12  text-start  text-md-end">
                                                    <form action="<?php echo e(route('cart.checkout')); ?>" method="post">
                                                        <?php echo csrf_field(); ?>
                                                        <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <input type="hidden" name="cart_id[]"
                                                                value="<?php echo e($cart->id); ?>">
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <button class="btn btn-line-fill btn-sm"
                                                            type="submit">Checkout</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td class="product-thumbnail"><a href="#"><img
                                                        src="<?php echo e(asset('frontend/assets/images/product_img1.jpg')); ?>"
                                                        alt="product1"></a></td>
                                            <td class="product-thumbnail"><a href="#"><img
                                                        src="<?php echo e(asset('frontend/assets/images/product_img1.jpg')); ?>"
                                                        alt="product1"></a></td>
                                            <td class="product-name" data-title="Product"><a
                                                    href="#"><?php echo e($cart->product->name); ?></a></td>
                                            <td class="product-price" data-title="Price"><?php echo e($cart->price); ?></td>
                                            <td class="product-quantity" data-title="Quantity"
                                                data-cart-id="<?php echo e($cart->id); ?>">
                                                <div class="quantity">
                                                    <input type="button" value="-" class="minus2">
                                                    <input id="product-amount-<?php echo e($cart->id); ?>" type="text" value="<?php echo e($cart->amount); ?>"
                                                        title="Qty" class="qty" size="4">
                                                    <input type="button" value="+" class="plus2">
                                                </div>
                                            </td>
                                            <td class="product-subtotal" data-title="Total" id="product-subtotal-<?php echo e($cart->id); ?>"><?php echo e($cart->total_payment); ?></td>
                                            <td class="product-remove" data-title="Remove">
                                                <form action="<?php echo e(route('cart.delete')); ?>" method="get">
                                                    <input type="hidden" name="id" value="<?php echo e($cart->id); ?>">
                                                    <button class="remove-product bg-transparent border-none"
                                                        type="submit"><i class="ti-close"></i></button>
                                                </form>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12">
                    <div class="medium_divider"></div>
                    <div class="divider center_icon"><i class="ti-shopping-cart-full"></i></div>
                    <div class="medium_divider"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script>
        const quantityElements = document.querySelectorAll('.product-quantity');
        quantityElements.forEach(quantityElement => {
            const minus2Button = quantityElement.querySelector('.minus2');
            const plus2Button = quantityElement.querySelector('.plus2');
            var qtyInput = quantityElement.querySelector('.qty');
            const cartId = quantityElement.getAttribute('data-cart-id');
            qtyInput.addEventListener('change', ()=>{
                console.log(event);
                updateCart(cartId,event.target.value)
            })
            minus2Button.addEventListener('click', () => {
                // Decrease the quantity by 1, but ensure it doesn't go below 1
                var currentQty = parseInt(qtyInput.value);
                if (currentQty > 1) {
                    currentQty--;
                    updateCart(cartId, currentQty);
                }
            });

            plus2Button.addEventListener('click', () => {
            var currentQty = parseInt(qtyInput.value);
                // Increase the quantity by 1
                currentQty++;
                updateCart(cartId, currentQty);
            });
        });

        function updateCart(cartId, newQty) {
            // Send an AJAX request to update the cart quantity
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo e(route('cart.update')); ?>",
                data: {
                    cart_id: cartId,
                    amount: newQty,
                    _token: "<?php echo e(csrf_token()); ?>"
                },
                success: function(response) {
                    // Handle the response, e.g., update the total price or display a message
                    const updatedTotalPayment = response.total_payment;

                    // Update the displayed total payment in the table cell
                    const totalPaymentCell = document.getElementById('product-subtotal-'+response.id);
                    document.getElementById('product-amount-'+response.id).value = response.amount;
                    totalPaymentCell.textContent = updatedTotalPayment;
                },
                error: function(xhr) {
                    console.log(xhr);
                    // Handle errors if the request fails
                    const qty = document.getElementById('product-amount-'+xhr.responseJSON.id);
                    const updateQty = xhr.responseJSON.error;
                    qty.value = updateQty;
                    currentQty = updateQty;
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/cart/index.blade.php ENDPATH**/ ?>