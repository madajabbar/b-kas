<div class="page-title">
    <div class="row">
        <div class="col-12 col-md-6 order-md-1 order-last">
            
            <p class="text-subtitle text-muted">
            </p>
        </div>
        <div class="col-12 col-md-6 order-md-2 order-first">
            <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('dashboard.index')); ?>">Dashboard</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">
                        <?php echo e($title); ?>

                    </li>
                </ol>
            </nav>
        </div>
    </div>
</div>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/backend/layouts/page-title.blade.php ENDPATH**/ ?>