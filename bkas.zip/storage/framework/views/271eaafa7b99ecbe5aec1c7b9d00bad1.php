<div class="tab-pane fade active show" id="dashboard" role="tabpanel" aria-labelledby="dashboard-tab">
    <div class="card">
        <div class="card-header">
            <h3>Halo <?php echo e($user->name); ?></h3>
            <p>Your Product</p>
            <a href="<?php echo e(route('user.product.create')); ?>" class="btn btn-fill-out btn-radius">Add Product</a>
        </div>
        <div class="card-body">
            <div class="row">
                <?php $__currentLoopData = $user->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-3 col-sm-12">
                        <?php echo $__env->make('frontend.pages.user.product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/user/dashboard.blade.php ENDPATH**/ ?>