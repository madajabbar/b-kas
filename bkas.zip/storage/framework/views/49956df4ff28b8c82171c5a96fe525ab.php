<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/pages/fontawesome.css')); ?>" />
    <link rel="stylesheet"
        href="<?php echo e(asset('dist/assets/extensions/datatables.net-bs5/css/dataTables.bootstrap5.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/pages/datatables.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="page-heading">
        <?php echo $__env->make('backend.layouts.page-title', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <?php echo $__env->make('backend.product.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Basic Tables start -->
        <section class="section">
            <div class="card">
                <div class="card-header">
                    <button type="button" class="btn btn-outline-primary block input" data-bs-toggle="modal"
                        data-bs-target="#exampleModalCenter">
                        Add Data
                    </button>
                </div>
                <div class="card-body">
                    <table class="table" id="table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Description</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Discount</th>
                                <th>Discount Status</th>
                                <th>Category</th>
                                <th>Condition</th>
                                <th>User</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <!-- Basic Tables end -->
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
    <script src="<?php echo e(asset('dist/assets/extensions/jquery/jquery.min.js')); ?>"></script>
    <script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
    <script src="<?php echo e(asset('dist/assets/js/pages/datatables.js')); ?>"></script>

    <script>
        $(function() {
            var table = $('.table').DataTable({
                processing: true,
                serverSide: true,
                ajax: {
                    url: "<?php echo e(route('product.table')); ?>",
                    data: function(data) {
                        data.category = "<?php echo e($category); ?>";
                        data.condition = "<?php echo e($condition); ?>";
                        data.user = "<?php echo e($user); ?>";

                        return data;
                    }
                },
                columns: [{
                        data: 'name',
                        name: 'name'
                    },
                    {
                        data: 'description',
                        name: 'description'
                    },
                    {
                        data: 'quantity',
                        name: 'quantity'
                    },
                    {
                        data: 'price',
                        name: 'price'
                    },
                    {
                        data: 'discount',
                        name: 'discount'
                    },
                    {
                        data: 'discount_status',
                        name: 'discount_status'
                    },
                    {
                        data: 'category.name',
                        name: 'category.name'
                    },
                    {
                        data: 'condition.name',
                        name: 'condition.name'
                    },
                    {
                        data: 'user.name',
                        name: 'user.name'
                    },
                    {
                        data: 'action',
                        name: 'action'
                    },
                ]
            });
        });
    </script>
    <script>
        $('body').on('click', '.input', function() {
            $('#name').val('');
            $('#saveBtn').html("Save");
        })
        $('body').on('click', '.edit', function() {
            var data_id = $(this).data('id');
            $.get("<?php echo e(route('product.index')); ?>" + '/' + data_id + '/edit', function(data) {
                $('#exampleModalCenterTitle').html("Edit");
                $('#saveBtn').html("edit");
                $('#exampleModalCenter').modal('show');
                $('#id').val(data.id);
                $('#name').val(data.name);
                $('#description').val(data.description);
                $('#price').val(data.price);
                $('#quantity').val(data.quantity);
                $('#discount').val(data.discount);
                $('#discount_status').val(data.discount_status);
                $("#user_id option").filter(function () {
                    console.log(data.user_id);
                    return $.trim($(this).val()) == data.user_id
                }).prop('selected', true);
                $("#condition_id option").filter(function () {
                    console.log(data.condition_id);
                    return $.trim($(this).val()) == data.condition_id
                }).prop('selected', true);
                $("#category_id option").filter(function () {
                    console.log(data.category_id);
                    return $.trim($(this).val()) == data.category_id
                }).prop('selected', true);
            })
        });
        $('body').on('click', '.delete', function() {
            var data_id = $(this).data('id');
            console.log(data_id);
            Swal.fire({
                title: 'Do you want to save delete this condition?',
                showDenyButton: true,
                showCancelButton: true,
                confirmButtonText: 'Yes',
                denyButtonText: `No`,
            }).then((result) => {
                /* Read more about isConfirmed, isDenied below */
                if (result.isConfirmed) {
                    var csrfToken = $('meta[name="csrf-token"]').attr('content'); // Get CSRF token
                    $.ajax({
                        cache: false,
                        headers: {
                            'X-CSRF-TOKEN': csrfToken // Include CSRF token in the request headers
                        },
                        contentType: false,
                        processData: false,
                        url: "<?php echo e(route('product.destroy', '')); ?>" + "/" + data_id,
                        type: 'DELETE',
                        _token: $('meta[name="csrf-token"]').attr('content'),
                        success: function(data) {
                            $('#exampleModalCenter').modal('hide');
                            $('#saveBtn').html('success');
                            // $('#name').val('');
                            Swal.fire({
                                icon: 'success',
                                title: 'Data berhasil dihapus',
                            })
                            reloadDatatable();
                        },
                        error: function(data) {
                            console.log('Error:', data);
                            Swal.fire({
                                icon: 'error',
                                title: 'Terjadi Error!',
                            })
                            $('#saveBtn').html('Error');
                        }
                    })
                    Swal.fire('Saved!', '', 'success')
                } else if (result.isDenied) {
                    Swal.fire('Changes are not saved', '', 'info')
                }
            })
        });
        $(function() {
            $('#saveBtn').click(function(e) {
                e.preventDefault();
                $(this).html('Sending..');
                var myform = document.getElementById('dataForm');
                var formData = new FormData(myform);
                $.ajax({
                    data: formData,
                    cache: false,
                    contentType: false,
                    processData: false,
                    url: "<?php echo e(route('product.store')); ?>",
                    type: "POST",
                    dataType: 'json',
                    success: function(data) {
                        $('#exampleModalCenter').modal('hide');
                        $('#saveBtn').html('success');
                        // $('#name').val('');
                        Swal.fire({
                            icon: 'success',
                            title: 'Data berhasil dimasukan',
                        })
                        reloadDatatable();
                    },
                    error: function(data) {
                        console.log('Error:', data);
                        Swal.fire({
                            icon: 'error',
                            title: 'Terjadi Error!',
                        })
                        $('#saveBtn').html('Error');
                    }
                });
            });
        });
    </script>
    <script>
        function reloadDatatable() {
            $('.table').DataTable().ajax.reload();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Laravel\bkas\resources\views/backend/product/index.blade.php ENDPATH**/ ?>