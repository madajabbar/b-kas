<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Meta -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Beli dan jual barang bekas berkualitas di BKASID.com. Temukan berbagai pilihan barang bekas terbaik untuk kebutuhan Anda.">
    <meta name="keywords" content="belanja barang bekas, jual barang bekas, barang bekas berkualitas, situs jual beli barang bekas">
    <meta name="author" content="BKASID">
    <meta name="robots" content="index, follow">
    <meta name="og:title" content="BKASID - Belanja Barang Bekas Berkualitas">
    <meta name="og:description" content="Beli dan jual barang bekas berkualitas di BKASID.com. Temukan berbagai pilihan barang bekas terbaik untuk kebutuhan Anda.">
    <meta name="og:image" content="<?php echo e(asset('frontend/Logo.png')); ?>">
    <meta name="og:url" content="https://www.bkasid.com/">
    <meta name="og:type" content="website">
    <meta name="og:locale" content="id_ID">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:site" content="@bkasid">
    <meta name="twitter:title" content="BKASID - Belanja Barang Bekas Berkualitas">
    <meta name="twitter:description" content="Beli dan jual barang bekas berkualitas di BKASID.com. Temukan berbagai pilihan barang bekas terbaik untuk kebutuhan Anda.">
    <meta name="twitter:image" content="<?php echo e(asset('frontend/Logo.png')); ?>">
    <meta name="twitter:url" content="https://www.bkasid.com/">
    <link rel="canonical" href="https://www.bkasid.com/">
    <!-- SITE TITLE -->
    <title>BKAS</title>
    <!-- Favicon Icon -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('frontend/assets/images/favicon.png')); ?>">
    <!-- Animation CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/animate.css')); ?>">
    <!-- Latest Bootstrap min CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/bootstrap/css/bootstrap.min.css')); ?>">
    <!-- Google Font -->
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700,900&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css?family=Poppins:200,300,400,500,600,700,800,900&display=swap"
        rel="stylesheet">
    
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Icon Font CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/all.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/ionicons.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/themify-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/linearicons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/flaticon.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/simple-line-icons.css')); ?>">
    <!--- owl carousel CSS-->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/owlcarousel/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/owlcarousel/css/owl.theme.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/owlcarousel/css/owl.theme.default.min.css')); ?>">
    <!-- Magnific Popup CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/jquery-ui.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/magnific-popup.css')); ?>">
    <!-- Slick CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/slick.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/slick-theme.css')); ?>">
    <!-- Style CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('frontend/assets/css/responsive.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>

    <!-- LOADER -->
    <div class="preloader" id="preloader">
        <div class="lds-ellipsis">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <!-- END LOADER -->

    <!-- Home Popup Section -->
    <?php echo $__env->make('frontend.layouts.util.popup', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End Screen Load Popup Section -->

    <!-- START HEADER -->
    <?php echo $__env->make('frontend.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END HEADER -->

    <!-- START SECTION BANNER -->
    <?php echo $__env->yieldContent('banner'); ?>
    <!-- END SECTION BANNER -->

    <!-- END MAIN CONTENT -->
    <div class="main_content">
        <?php echo $__env->yieldContent('content'); ?>
    </div>
    <!-- END MAIN CONTENT -->

    <!-- START FOOTER -->
    <?php echo $__env->make('frontend.layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- END FOOTER -->

    <a href="#" class="scrollup" style="display: none;"><i class="ion-ios-arrow-up"></i></a>

    <!-- Latest jQuery -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery-3.6.0.min.js')); ?>"></script>
    
    <script src="<?php echo e(asset('frontend/assets/js/jquery-ui.js')); ?>"></script>
    <!-- popper min js -->
    <script src="<?php echo e(asset('frontend/assets/js/popper.min.js')); ?>"></script>
    <!-- Latest compiled and minified Bootstrap -->
    <script src="<?php echo e(asset('frontend/assets/bootstrap/js/bootstrap.min.js')); ?>"></script>
    
    <!-- owl-carousel min js  -->
    <script src="<?php echo e(asset('frontend/assets/owlcarousel/js/owl.carousel.min.js')); ?>"></script>
    <!-- magnific-popup min js  -->
    <script src="<?php echo e(asset('frontend/assets/js/magnific-popup.min.js')); ?>"></script>
    <!-- waypoints min js  -->
    <script src="<?php echo e(asset('frontend/assets/js/waypoints.min.js')); ?>"></script>
    <!-- parallax js  -->
    <script src="<?php echo e(asset('frontend/assets/js/parallax.js')); ?>"></script>
    <!-- countdown js  -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery.countdown.min.js')); ?>"></script>
    <!-- imagesloaded js -->
    <script src="<?php echo e(asset('frontend/assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
    <!-- isotope min js -->
    <script src="<?php echo e(asset('frontend/assets/js/isotope.min.js')); ?>"></script>
    <!-- jquery.dd.min js -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery.dd.min.js')); ?>"></script>
    <!-- slick js -->
    <script src="<?php echo e(asset('frontend/assets/js/slick.min.js')); ?>"></script>
    <!-- elevatezoom js -->
    <script src="<?php echo e(asset('frontend/assets/js/jquery.elevatezoom.js')); ?>"></script>
    <!-- scripts js -->
    <script src="<?php echo e(asset('frontend/assets/js/scripts.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            $.get('/api/category', function(data) {
                var categoryDropdown = $('#categoryDropdown');
                data.forEach(function(category) {
                    var form = $('<form>')
                        .attr('action', ' ') // Set your desired action URL here
                        .attr('method', 'GET');

                    var categoryInput = $('<input>')
                        .attr('type', 'hidden')
                        .attr('name', 'category_id') // Use the appropriate input name
                        .val(category.slug); // Use the category ID or relevant identifier

                    var submitButton = $('<button>')
                        .addClass('dropdown-item menu-link')
                        .attr('type', 'submit')
                        .text(category.name);

                    form.append(categoryInput, submitButton);
                    var categoryItem = $('<li>').append(form);
                    categoryDropdown.append(categoryItem);
                });
            });
        });
    </script>
    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/layouts/app.blade.php ENDPATH**/ ?>