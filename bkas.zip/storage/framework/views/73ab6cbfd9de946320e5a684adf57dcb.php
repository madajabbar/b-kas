<footer class="footer_dark">
    <div class="bottom_footer border-top-tran">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <p class="mb-md-0 text-center">© 2023 All Rights Reserved by Bkasid.com</p>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>