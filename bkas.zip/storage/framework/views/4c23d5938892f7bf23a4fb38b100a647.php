<div class="product">
    <form id="<?php echo e($data->ulid); ?>" action="<?php echo e(route('productDetail')); ?>" method="get">
        <input type="hidden" name="product" value="<?php echo e($data->ulid); ?>">
    </form>
    <div class="product_img">
        <a href="<?php echo e(route('productDetail',['product'=>$data->ulid])); ?>">
            <?php if(count($data->productImage) > 0): ?>
            <img src="<?php echo e(asset('storage/'.$data->productImage[0]->link)); ?>" alt="product_img1" />
            <?php else: ?>
            <img src="<?php echo e(asset('frontend/assets/images/product_img1.jpg')); ?>" alt="product_img1" />
            <?php endif; ?>
        </a>
        <div class="product_action_box">
            <ul class="list_none pr_action_btn">
                <li class="add-to-cart">
                    <a href="javascript:void(0);" onclick="document.getElementById('<?php echo e($data->ulid); ?>').submit()">
                        <i class="icon-basket-loaded"></i>
                        Add To Cart</a>
                </li>
                <li>
                    <a href="<?php echo e(route('quickview',$data->ulid)); ?>" class="popup-ajax"><i class="icon-magnifier-add"></i></a>
                </li>
                <li>
                    <a href="#"><i class="icon-heart"></i></a>
                </li>
            </ul>
        </div>
    </div>
    <div class="product_info">
        <h6 class="product_title">
            <form action="<?php echo e(route('productDetail')); ?>" method="get">
                <input type="hidden" name="product" value="<?php echo e($data->ulid); ?>">
                <button class="btn border-none bg-none" type="submit"><?php echo e($data->name); ?></button>
            </form>
        </h6>
        <div class="product_price">
            <span class="price">Rp. <?php echo e($data->price); ?></span>
        </div>
        <div class="rating_wrap">
            <div class="rating">
                <div class="product_rate" style="width: 80%"></div>
            </div>
            <span class="rating_num"><?php echo e($data->quantity); ?></span>
        </div>
    </div>
</div>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/layouts/util/product.blade.php ENDPATH**/ ?>