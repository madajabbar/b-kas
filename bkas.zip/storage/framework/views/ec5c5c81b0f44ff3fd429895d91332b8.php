<div class="tab-pane fade" id="chat" role="tabpanel" aria-labelledby="chat-tab">
    <div class="row">
        <div class="col">
            <div class="card mb-3 mb-lg-0">
                <div class="card-header">
                    <h3>Chat</h3>
                </div>
                <div class="card-body">
                    <ul>
                        <?php $__currentLoopData = $chat_rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li>
                                <a href="">
                                    <i class="linearicons-store"></i>
                                    Toko <?php echo e($chat->user->name); ?>

                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/user/chat.blade.php ENDPATH**/ ?>