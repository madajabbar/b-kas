<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Mazer Admin Dashboard</title>

    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/main/app.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/main/app-dark.css')); ?>">
    <link rel="shortcut icon" href="<?php echo e(asset('dist/assets/images/logo/favicon.svg')); ?>" type="image/x-icon">
    <link rel="shortcut icon" href="<?php echo e(asset('dist/assets/images/logo/favicon.png')); ?>" type="image/png">
    <link rel="stylesheet" href="<?php echo e(asset('dist/assets/css/shared/iconly.css')); ?>">
    <?php echo $__env->yieldContent('css'); ?>
</head>

<body>
    <div id="app">
        <?php echo $__env->make('backend.layouts.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div id="main">
            <header class="mb-3">
                <a href="#" class="burger-btn d-block d-xl-none">
                    <i class="bi bi-justify fs-3"></i>
                </a>
            </header>

            <div class="page-heading">
                <h3><?php echo e($title); ?></h3>
            </div>
            <?php echo $__env->yieldContent('content'); ?>

        </div>
    </div>
    <script src="<?php echo e(asset('dist/assets/js/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('dist/assets/js/app.js')); ?>"></script>
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <?php echo $__env->yieldContent('js'); ?>

</body>

</html>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>