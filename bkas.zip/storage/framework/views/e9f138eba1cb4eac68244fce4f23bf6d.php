<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main_content">
        <!-- START SECTION SHOP -->
        <div class="section">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
                        <div class="product-image">
                            <div class="product_img_box">
                                    <img id="product_img" src="<?php echo e(asset('frontend/assets/images/product_img1.jpg')); ?>"
                                        data-zoom-image="<?php echo e(asset('frontend/assets/images/product_zoom_img1.jpg')); ?>"
                                        alt="product_img1" />
                                    <a href="#" class="product_img_zoom" title="Zoom">
                                        <span class="linearicons-zoom-in"></span>
                                    </a>
                            </div>
                            <div id="pr_item_gallery" class="product_gallery_item slick_slider" data-slides-to-show="4"
                                data-slides-to-scroll="1" data-infinite="false">
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="pr_detail">
                            <div class="product_description">
                                <h4 class="product_title">
                                    <a href="#"><?php echo e($seller->name); ?></a>
                                </h4>
                                <div class="rating_wrap">
                                    <div class="rating">
                                        <div class="product_rate" style="width: 80%"></div>
                                    </div>
                                    <span class="rating_num">(<?php echo e(count($seller->product)); ?>)</span>
                                </div>
                                <div class="pr_desc">
                                    <p>
                                       Alamat <br> <?php echo e($seller->userData->address); ?>

                                    </p>
                                </div>
                                <div class="product_sort_info">
                                    <ul>
                                            <li>
                                                <i class="linearicons-map-marker"></i>
                                                 <?php echo e($seller->userData->city->name); ?>

                                            </li>
                                            <li>
                                                <i class="linearicons-map-marker"></i>
                                                Provinsi <?php echo e($seller->userData->province->name); ?>

                                            </li>
                                    </ul>
                                </div>
                            </div>
                            <hr />
                                <div class="cart_extra">
                                    <div class="cart_btn">
                                        <a class="btn btn-fill-out btn-addtocart" href="<?php echo e(route('chat', $seller->id)); ?>">
                                            <i class="icon-chat"></i>
                                            Chat
                                        </a>
                                        <a class="add_wishlist" href="#"><i class="icon-heart"></i></a>
                                    </div>
                                </div>
                            <hr />
                            <ul class="product-meta">
                                
                                
                                
                            </ul>

                            <div class="product_share">
                                <span>Share:</span>
                                <ul class="social_icons">
                                    <li>
                                        <a href="#"><i class="ion-social-facebook"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-twitter"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-googleplus"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-youtube-outline"></i></a>
                                    </li>
                                    <li>
                                        <a href="#"><i class="ion-social-instagram-outline"></i></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="small_divider"></div>
                        <div class="divider"></div>
                        <div class="medium_divider"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-12">
                        <div class="heading_s1">
                            <h3>Related Products</h3>
                        </div>
                        <div class="releted_product_slider carousel_slider owl-carousel owl-theme" data-margin="20"
                            data-responsive='{"0":{"items": "1"}, "481":{"items": "2"}, "768":{"items": "3"}, "1199":{"items": "4"}}'>
                            <?php $__currentLoopData = $seller->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo $__env->make('frontend.pages.product.detail.related_products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- END SECTION SHOP -->
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        $(document).ready(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            function storeProduct() {
                // Get the edited values from the content-editable fields
                var product_id = $('#product_id').val();
                var amount = $('#amount').val();

                // Prepare the data to send in the POST request
                var data = {
                    product_id: product_id,
                    amount: amount,
                };
                // Make the POST request to update the product
                $.ajax({
                    url: '<?php echo e(route('cart.store')); ?>',
                    type: 'POST',
                    data: data,
                    success: function(response) {
                        // Handle success, e.g., show a success message or redirect
                        console.log(response.success);
                        Swal.fire({
                            position: 'top-end',
                            icon: 'success',
                            title: response.success,
                            showConfirmButton: false,
                            timer: 1500
                        })
                    },
                    error: function(response) {
                        // Handle error, e.g., show an error message
                        console.error(response.responseJSON.error);
                        Swal.fire({
                            position: 'top-end',
                            icon: 'error',
                            title: response.responseJSON.error,
                            showConfirmButton: false,
                            timer: 1500
                        })
                    }
                });
            }

            $('.btn-addtocart').click(function() {
                storeProduct();
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/seller/index.blade.php ENDPATH**/ ?>