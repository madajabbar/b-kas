<?php $__env->startSection('css'); ?>
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main_content">
        <!-- START SECTION SHOP -->
        <div class="section">
            <div class="container">
                <?php if($product != null): ?>
                <button class="btn btn-fill-out my-2" type="button" data-bs-toggle="modal" data-bs-target="#image-popup">
                    <i class="icon-pencil"></i>
                    Add Image
                </button>

                <?php endif; ?>
                <?php echo $__env->make('frontend.pages.user.pop-image', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <div class="row">
                    <div class="col-lg-6 col-md-6 mb-4 mb-md-0">
                        <div class="product-image">
                            <div class="product_img_box">
                                <?php if($product != null): ?>
                                    <?php if(count($product->productImage) > 0): ?>
                                    <img id="product_img"
                                    src="<?php echo e(asset('storage/' . $product->productImage[0]->link)); ?>"
                                    data-zoom-image="<?php echo e(asset('storage/' . $product->productImage[0]->link)); ?>"
                                    alt="product_img1" />
                                    <?php else: ?>
                                    <img id="product_img" src="<?php echo e(asset('frontend/assets/images/product_img1-2.jpg')); ?>"
                                        data-zoom-image="<?php echo e(asset('frontend/assets/images/product_img1-2.jpg')); ?>"
                                        alt="product_img1" />
                                    <?php endif; ?>
                                    <a href="#" class="product_img_zoom" title="Zoom">
                                        <span class="linearicons-zoom-in"></span>
                                    </a>
                                <?php else: ?>
                                    <img id="product_img" src="<?php echo e(asset('frontend/assets/images/product_img1-2.jpg')); ?>"
                                        data-zoom-image="<?php echo e(asset('frontend/assets/images/product_img1-2.jpg')); ?>"
                                        alt="product_img1" />

                                    <a href="#" class="product_img_zoom" title="Zoom">
                                        <span class="linearicons-zoom-in"></span>
                                    </a>
                                <?php endif; ?>
                            </div>
                            <?php if($product != null): ?>
                                <div id="pr_item_gallery" class="product_gallery_item slick_slider" data-slides-to-show="4"
                                    data-slides-to-scroll="1" data-infinite="false">
                                    <?php $__currentLoopData = $product->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="item">
                                            <a href="#" class="product_gallery_item active"
                                                data-image="<?php echo e(asset('storage/' . $image->link)); ?>"
                                                data-zoom-image="<?php echo e(asset('storage/' . $image->link)); ?>">
                                                <img src="<?php echo e(asset('storage/' . $image->link)); ?>" alt="<?php echo e($image->name); ?>" />
                                            </a>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>

                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <form id="editProductForm">
                            <!-- Other form elements here -->
                            <div class="pr_detail">
                                <div class="product_description">
                                    <h4 class="product_title">
                                        <span>Name : </span>
                                        <span id="name"
                                            contenteditable="true"><?php echo e($product->name ?? 'Product Name'); ?></span>
                                        <sup><i class="icon-pencil"></i></sup>
                                    </h4>
                                    <div class="product_price">
                                        <span>Price (only input number) : Rp. </span>
                                        <span id="price" class="price"
                                            contenteditable="true"><?php echo e($product->price ?? 0); ?></span>
                                        <sup><i class="icon-pencil"></i></sup>
                                        <div class="on_sale">
                                            <span>Discount (only input number) : Rp. </span>
                                            <span id="discount"
                                                contenteditable="true"><?php echo e($product->discount ?? 0); ?></span>
                                            <sup><i class="icon-pencil"></i></sup>
                                        </div>
                                    </div>
                                    <div class="rating_wrap">
                                        <div class="rating">
                                            <div class="product_rate" style="width: 80%"></div>
                                        </div>
                                        <span class="rating_num">(<?php echo e($product->quantity ?? 0); ?>)</span>
                                    </div>
                                    <div class="pr_desc">
                                        <div class="row">
                                            <div class="col-11">
                                                <p id="description" contenteditable="true">
                                                    <?php echo e($product->description ?? 'Product Description'); ?>

                                                </p>
                                            </div>
                                            <div class="col-1">
                                                <sup><i class="icon-pencil"></i></sup>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <hr />
                                <div class="cart_extra">
                                    <div class="cart-product-quantity">
                                        <div class="quantity">
                                            <input type="button" value="-" class="minus" />
                                            <input type="text" id="quantity" name="quantity"
                                                value="<?php echo e($product->quantity ?? 0); ?>" title="Qty" class="qty"
                                                size="4" />
                                            <input type="button" value="+" class="plus" />
                                        </div>
                                    </div>
                                    <div class="cart_btn">
                                        <button class="btn btn-fill-out btn-addtocart" type="button">
                                            <i class="icon-pencil"></i>
                                            <?php echo e($product ? 'Edit' : 'Add'); ?>

                                        </button>
                                    </div>
                                </div>
                                <hr />
                                <ul class="product-meta">
                                    <li>Category:
                                        <select name="category_id" class="form-select" id="category_id">
                                            <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>"
                                                    <?php echo e($product ? ($product->category_id == $data->id ? 'selected' : '') : ''); ?>>
                                                    <?php echo e($data->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </li>
                                    <li>Condition:
                                        <select name="condition_id" class="form-select" id="condition_id">
                                            <?php $__currentLoopData = $condition; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($data->id); ?>"
                                                    <?php echo e($product ? ($product->condition_id == $data->id ? 'selected' : '') : ''); ?>>
                                                    <?php echo e($data->name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </li>
                                </ul>
                                <div class="product_share">
                                    <span>Share:</span>
                                    <ul class="social_icons">
                                        <li>
                                            <a href="#"><i class="ion-social-facebook"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="ion-social-twitter"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="ion-social-googleplus"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="ion-social-youtube-outline"></i></a>
                                        </li>
                                        <li>
                                            <a href="#"><i class="ion-social-instagram-outline"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </form>
                    </div>
                    <div class="col-6">
                        <?php if(isset($product->productImage)): ?>
                            <?php $__currentLoopData = $product->productImage; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="btn btn-danger btn-sm mx-auto"
                                    href="<?php echo e(route('user.product.image.delete', $image->ulid)); ?>">Hapus Gambar
                                    <?php echo e($loop->iteration); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                    </div>
                </div>

            </div>
        </div>
        <!-- END SECTION SHOP -->
    <?php $__env->stopSection(); ?>

    <?php $__env->startSection('js'); ?>
        <script>
            $(document).ready(function() {
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });

                function storeProduct() {
                    // Get the edited values from the content-editable fields
                    var newName = $('#name').text();
                    var newPrice = $('#price').text();
                    var newDiscount = $('#discount').text();
                    var newDescription = $('#description').text();
                    var newQuantity = $('#quantity').val();
                    var newCategoryId = $('#category_id').val();
                    var newConditionId = $('#condition_id').val();
                    var productId = '<?php echo e($product->id ?? null); ?>'
                    // Prepare the data to send in the POST request
                    var data = {
                        id: productId,
                        name: newName,
                        price: newPrice,
                        discount: newDiscount,
                        description: newDescription,
                        quantity: newQuantity,
                        user_id: <?php echo e(Auth::user()->id); ?>,
                        condition_id: newConditionId,
                        category_id: newCategoryId,


                    };
                    // Make the POST request to update the product
                    $.ajax({
                        url: '<?php echo e(route('user.product')); ?>',
                        type: 'POST',
                        data: data,
                        success: function(response) {
                            // Handle success, e.g., show a success message or redirect
                            console.log(response);
                            Swal.fire({
                                position: 'top-end',
                                icon: 'success',
                                title: 'Product Has Changed',
                                showConfirmButton: false,
                                timer: 1500
                            })
                        },
                        error: function(error) {
                            // Handle error, e.g., show an error message
                            console.error(error);
                            Swal.fire({
                                position: 'top-end',
                                icon: 'error',
                                title: 'Error',
                                showConfirmButton: false,
                                timer: 1500
                            })
                        }
                    });
                }

                $('.btn-addtocart').click(function() {
                    storeProduct();
                });
            });
        </script>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/user/product-edit.blade.php ENDPATH**/ ?>