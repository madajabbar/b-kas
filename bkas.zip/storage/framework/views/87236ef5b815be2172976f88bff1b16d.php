
<div class="tab-pane fade" id="orders" role="tabpanel" aria-labelledby="orders-tab">
    <div class="card">
        <div class="card-header">
            <h3>Orders</h3>
        </div>
        <div class="card-body">
            <div class="table-responsive">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Order</th>
                            <th>Date</th>
                            <th>Status</th>
                            <th>Total</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($order->order_id); ?></td>
                                <td>
                                    <?php echo e(\Carbon\Carbon::parse($order->created_at)->format('d F Y')); ?>

                                </td>
                                <td><?php echo e($order->status); ?></td>
                                <td>
                                    Rp. <?php echo e($order->total_payment); ?> for <?php echo e(count($order->orderDetail)); ?>

                                    item
                                </td>
                                <td>
                                    <a href="<?php echo e(route('order.user',['ulid'=>$order->ulid])); ?>" class="btn btn-fill-out btn-sm">View</a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php /**PATH D:\Code\Laravel\bkas\resources\views/frontend/pages/user/orders.blade.php ENDPATH**/ ?>